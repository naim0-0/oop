#include <stdio.h>
#include <stdlib.h>

#define MAX 100

// Node structure
typedef struct Node {
    char data;
    int freq;
    struct Node *left, *right;
} Node;

// Min Heap structure
typedef struct {
    int size;
    Node* arr[MAX];
} MinHeap;

// Create new node
Node* createNode(char data, int freq) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = data;
    node->freq = freq;
    node->left = node->right = NULL;
    return node;
}

// Swap nodes
void swap(Node** a, Node** b) {
    Node* temp = *a;
    *a = *b;
    *b = temp;
}

// Heapify
void heapify(MinHeap* heap, int i) {
    int smallest = i;
    int left = 2*i + 1;
    int right = 2*i + 2;

    if (left < heap->size && heap->arr[left]->freq < heap->arr[smallest]->freq)
        smallest = left;

    if (right < heap->size && heap->arr[right]->freq < heap->arr[smallest]->freq)
        smallest = right;

    if (smallest != i) {
        swap(&heap->arr[i], &heap->arr[smallest]);
        heapify(heap, smallest);
    }
}

// Extract min
Node* extractMin(MinHeap* heap) {
    Node* temp = heap->arr[0];
    heap->arr[0] = heap->arr[heap->size - 1];
    heap->size--;
    heapify(heap, 0);
    return temp;
}

// Insert into heap
void insertHeap(MinHeap* heap, Node* node) {
    int i = heap->size++;
    heap->arr[i] = node;

    while (i && heap->arr[(i - 1)/2]->freq > heap->arr[i]->freq) {
        swap(&heap->arr[i], &heap->arr[(i - 1)/2]);
        i = (i - 1)/2;
    }
}

// Build Huffman Tree
Node* buildHuffman(char data[], int freq[], int n) {
    MinHeap heap;
    heap.size = 0;

    for (int i = 0; i < n; i++)
        insertHeap(&heap, createNode(data[i], freq[i]));

    while (heap.size > 1) {
        Node* left = extractMin(&heap);
        Node* right = extractMin(&heap);

        Node* merged = createNode('$', left->freq + right->freq);
        merged->left = left;
        merged->right = right;

        insertHeap(&heap, merged);
    }

    return extractMin(&heap);
}

// Print codes
void printCodes(Node* root, int arr[], int top) {
    if (root->left) {
        arr[top] = 0;
        printCodes(root->left, arr, top + 1);
    }

    if (root->right) {
        arr[top] = 1;
        printCodes(root->right, arr, top + 1);
    }

    if (!root->left && !root->right) {
        printf("%c: ", root->data);
        for (int i = 0; i < top; i++)
            printf("%d", arr[i]);
        printf("\n");
    }
}

int main() {
    int n;
    char data[MAX];
    int freq[MAX];

    printf("Enter number of characters: ");
    scanf("%d", &n);

    printf("Enter characters:\n");
    for (int i = 0; i < n; i++)
        scanf(" %c", &data[i]);

    printf("Enter frequencies:\n");
    for (int i = 0; i < n; i++)
        scanf("%d", &freq[i]);

    Node* root = buildHuffman(data, freq, n);

    int arr[MAX], top = 0;

    printf("\nHuffman Codes:\n");
    printCodes(root, arr, top);

    return 0;
}