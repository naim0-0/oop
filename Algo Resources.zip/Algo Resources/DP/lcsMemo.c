#include <stdio.h>
#include <string.h>

#define MAX 100

int dp[MAX][MAX];

// Function to compute LCS using memoization (top-down)
int lcs(char A[], char B[], int i, int j) {
    if (i == 0 || j == 0)
        return 0;

    if (dp[i][j] != -1)
        return dp[i][j];

    if (A[i - 1] == B[j - 1])
        dp[i][j] = 1 + lcs(A, B, i - 1, j - 1);
    else {
        int x = lcs(A, B, i - 1, j);
        int y = lcs(A, B, i, j - 1);
        dp[i][j] = (x > y) ? x : y;
    }

    return dp[i][j];
}

int main() {
    char A[MAX], B[MAX];

    printf("Enter first string: ");
    scanf("%s", A);

    printf("Enter second string: ");
    scanf("%s", B);

    int n = strlen(A);
    int m = strlen(B);

    // Initialize dp table with -1
    for (int i = 0; i <= n; i++)
        for (int j = 0; j <= m; j++)
            dp[i][j] = -1;

    int length = lcs(A, B, n, m);

    printf("\nLCS Length: %d\n", length);

    // Backtracking to find actual LCS
    int i = n, j = m;
    char C[MAX];
    C[length] = '\0';  // null-terminate string
    int index = length - 1;

    while (i > 0 && j > 0) {
        if (A[i - 1] == B[j - 1]) {
            C[index] = A[i - 1];
            index--;
            i--;
            j--;
        } else if (dp[i - 1][j] > dp[i][j - 1]) {
            i--;
        } else {
            j--;
        }
    }

    printf("LCS String: %s\n", C);

    return 0;
}