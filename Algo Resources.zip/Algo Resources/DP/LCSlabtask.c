#include <stdio.h>
#include <string.h>

#define MAX_WORDS 1000
#define MAX_LEN 100

int c[MAX_WORDS + 1][MAX_WORDS + 1];

void lcsLength(char words1[][MAX_LEN], char words2[][MAX_LEN], int len1, int len2) {

    for (int i = 0; i <= len1; i++)
    {
        c[i][0] = 0;
    }

    for (int j = 0; j <= len2; j++)
    {
        c[0][j] = 0;
    }

    for (int i = 1; i <= len1; i++) 
    {
        for (int j = 1; j <= len2; j++) 
        {
            if (strcmp(words1[i - 1], words2[j - 1]) == 0) 
            {
                c[i][j] = c[i - 1][j - 1] + 1;
            } 
            else if (c[i - 1][j] >= c[i][j - 1]) 
            {
                c[i][j] = c[i - 1][j];
            } 
            else 
            {
                c[i][j] = c[i][j - 1];
            }
        }
    }

    printf("%d\n", c[len1][len2]);
}

void printLCS(char words1[][MAX_LEN], char words2[][MAX_LEN], int i, int j) {

    if (i == 0 || j == 0)
    {
        return;
    }

    if (strcmp(words1[i - 1], words2[j - 1]) == 0) 
    {
        printLCS(words1, words2, i - 1, j - 1);
        printf("%s ", words1[i - 1]);
    } 
    else if (c[i - 1][j] > c[i][j - 1]) 
    {
        printLCS(words1, words2, i - 1, j);
    } 
    else 
    {
        printLCS(words1, words2, i, j - 1);
    }
}

int main() {

    char str1[10000], str2[10000];
    char words1[MAX_WORDS][MAX_LEN];
    char words2[MAX_WORDS][MAX_LEN];
    int len1 = 0, len2 = 0;

    FILE *f1 = fopen("file1.txt", "r");
    FILE *f2 = fopen("file2.txt", "r");

    fgets(str1, sizeof(str1), f1);
    fgets(str2, sizeof(str2), f2);


    char *token = strtok(str1, " ");

    while (token != NULL && len1 < MAX_WORDS) 
    {
        strcpy(words1[len1], token);
        len1++;
        token = strtok(NULL, " ");
    }

    token = strtok(str2, " ");

    while (token != NULL && len2 < MAX_WORDS) 
    {
        strcpy(words2[len2], token);
        len2++;
        token = strtok(NULL, " ");
    }

    lcsLength(words1, words2, len1, len2);

    printLCS(words1, words2, len1, len2);
    

    return 0;
}
