#include <stdio.h>
#include <string.h>

#define MAX 10000

int memo[MAX][MAX];

int min(int a, int b, int c) {

    if (a<b && a<c)
    {
        return a;
    }
    else if (b<c)
    {
        return b;
    }

    return c;
    
}

int editDistance(char *x, char *y, int i, int j) {

    if (j == 0)
    {
        return i;
    }

    if (i == 0)
    {
        return j;
    }

    if (memo[i][j] != -1)
    {
        return memo[i][j];
    }
    

    if (x[i-1] == y[j-1])
    {
        memo[i][j] = editDistance(x, y, i-1, j-1);
    }
    else 
    {
        memo[i][j] = min(editDistance(x, y, i-1, j-1), editDistance(x, y, i-1, j), editDistance(x, y, i, j-1)) + 1;
    }
    
    return memo[i][j];
}

int main() {

    int n;

    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        char str1[1000];
        char str2[1000];
        scanf("%s %s", str1, str2);

        int len1 = strlen(str1);
        int len2 = strlen(str2);

        printf("Test Case %d: \n", i+1);

        for(int i=0; i < MAX; i++)
        {
            for(int j=0; j < MAX; j++)
            {
                memo[i][j] = -1;
            }
        }

        int ed = editDistance(str1, str2, len1, len2);

        printf("Number of operations: %d\n", ed);    
    }

}