#include <stdio.h>

#define ROW 4
#define COL 5

int C[ROW][COL] = {
    {3,2,5,4,8},
    {5,7,5,6,1},
    {4,4,6,2,3},
    {2,8,9,5,8}
};

int A[ROW][COL];
int parent[ROW][COL];

int min(int x, int y) { return (x < y) ? x : y; }

int main() {
    // First row
    for (int j = 0; j < COL; j++) {
        A[0][j] = C[0][j];
        parent[0][j] = -1; // no parent
    }

    // Fill DP table
    for (int i = 1; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            int best = A[i-1][j];
            int par = j;

            if (j > 0 && A[i-1][j-1] < best) { best = A[i-1][j-1]; par = j-1; }
            if (j < COL-1 && A[i-1][j+1] < best) { best = A[i-1][j+1]; par = j+1; }

            A[i][j] = C[i][j] + best;
            parent[i][j] = par;
        }
    }

    // Find minimum in last row
    int minCol = 0;
    for (int j = 1; j < COL; j++)
        if (A[ROW-1][j] < A[ROW-1][minCol])
            minCol = j;

    // Reconstruct path
    int path[ROW];
    int curCol = minCol;
    for (int i = ROW-1; i >= 0; i--) {
        path[i] = C[i][curCol];
        curCol = parent[i][curCol];
    }

    // Print path
    printf("Path: ");
    for (int i = 0; i < ROW; i++)
        printf("%d ", path[i]);
    printf("\n");

    printf("Minimum sum: %d\n", A[ROW-1][minCol]);

    return 0;
}
