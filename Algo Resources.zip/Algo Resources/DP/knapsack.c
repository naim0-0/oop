#include <stdio.h>

int max(int a, int b) {
    return (a > b) ? a : b;
}

void knapsack01(int w[], int v[], int n, int W) {
    int P[n + 1][W + 1];

    // Base cases
    for (int i = 0; i <= n; i++)
        P[i][0] = 0;

    for (int wgt = 0; wgt <= W; wgt++)
        P[0][wgt] = 0;

    // Fill DP table
    for (int i = 1; i <= n; i++) {
        for (int wgt = 0; wgt <= W; wgt++) {
            if (w[i - 1] > wgt) {
                P[i][wgt] = P[i - 1][wgt];
            } else {
                P[i][wgt] = max(
                    v[i - 1] + P[i - 1][wgt - w[i - 1]],
                    P[i - 1][wgt]
                );
            }
        }
    }

    // Print maximum value
    printf("Maximum value: %d\n", P[n][W]);

    // -------- PRINT PATH (selected items) --------
    int i = n, wgt = W;

    printf("Selected items (index, weight, value):\n");

    while (i > 0 && wgt > 0) {
        // If value comes from the item being included
        if (P[i][wgt] != P[i - 1][wgt]) {
            printf("Item %d (w=%d, v=%d)\n", i, w[i - 1], v[i - 1]);
            wgt -= w[i - 1];  // reduce remaining capacity
        }
        i--;  // move to previous item
    }
}

int main() {
    int weights[] = {2, 3, 4, 5};
    int values[]  = {3, 4, 5, 6};
    int W = 5;
    int n = sizeof(weights) / sizeof(weights[0]);

    knapsack01(weights, values, n, W);

    return 0;
}
