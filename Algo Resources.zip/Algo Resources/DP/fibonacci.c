#include <stdio.h>

#define MAX 10000
int memo[MAX];

int fibonacci(int n) {

    if (memo[n] != -1)
    {
        return memo[n];     // table hit
    }

    if (n <= 1)
    {
        memo[n] = 1;
    }

    memo[n] = fibonacci(n-1) + fibonacci(n-2);
    
    return memo[n];
    
}

int main() {

    int n;

    scanf("%d", &n);

    for (int i = 0; i < MAX; i++)
    {
        memo[i] = -1;   // table initialization
    }

    int x = fibonacci(n);

    printf("%d", x);
}