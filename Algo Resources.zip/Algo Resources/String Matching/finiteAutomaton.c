#include <stdio.h>
#include <string.h>

#define MAX 256   // ASCII input size

int getNextState(char pattern[], int m, int state, int x) {
    if (state < m && x == pattern[state])
        return state + 1;

    int ns, i;

    for (ns = state; ns > 0; ns--) {
        if (pattern[ns - 1] == x) {
            for (i = 0; i < ns - 1; i++)
                if (pattern[i] != pattern[state - ns + 1 + i])
                    break;

            if (i == ns - 1)
                return ns;
        }
    }

    return 0;
}

void buildDFA(char pattern[], int m, int TF[][MAX]) {
    int state, x;

    for (state = 0; state <= m; state++) {
        for (x = 0; x < MAX; x++) {
            TF[state][x] = getNextState(pattern, m, state, x);
        }
    }
}

void search(char text[], char pattern[]) {
    int n = strlen(text);
    int m = strlen(pattern);

    int TF[m + 1][MAX];

    buildDFA(pattern, m, TF);

    int state = 0;

    for (int i = 0; i < n; i++) {
        state = TF[state][(unsigned char)text[i]];

        if (state == m) {
            printf("Pattern found at index %d\n", i - m + 1);
        }
    }
}

int main() {
    char text[1000], pattern[100];

    printf("Enter text: ");
    scanf("%s", text);

    printf("Enter pattern: ");
    scanf("%s", pattern);

    search(text, pattern);

    return 0;
}