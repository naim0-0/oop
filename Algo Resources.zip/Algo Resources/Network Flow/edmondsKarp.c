#include <stdio.h>
#include <string.h>

#define MAX 100
#define INF 99999

int graph[MAX][MAX];
int residual[MAX][MAX];
int parent[MAX];
int visited[MAX];
int n;

// BFS to find shortest augmenting path
int bfs(int source, int sink) {
    int queue[MAX], front = 0, rear = 0;

    memset(visited, 0, sizeof(visited));
    memset(parent, -1, sizeof(parent));

    queue[rear++] = source;
    visited[source] = 1;

    while (front < rear) {
        int u = queue[front++];

        for (int v = 0; v < n; v++) {
            if (!visited[v] && residual[u][v] > 0) {
                queue[rear++] = v;
                parent[v] = u;
                visited[v] = 1;

                if (v == sink)
                    return 1;
            }
        }
    }

    return 0;
}

void printPath(int source, int sink) {
    int path[MAX];
    int count = 0;

    for (int v = sink; v != -1; v = parent[v])
        path[count++] = v;

    printf("Augmenting Path: ");
    for (int i = count - 1; i >= 0; i--) {
        printf("%d", path[i]);
        if (i != 0) printf(" -> ");
    }
    printf("\n");
}

int edmondsKarp(int source, int sink) {
    int maxFlow = 0;
    int step = 1;

    // Initialize residual graph
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            residual[i][j] = graph[i][j];

    printf("\nInitial Residual Graph:\n");

    while (bfs(source, sink)) {

        printf("\nStep %d\n", step++);

        // Print path
        printPath(source, sink);

        // Find bottleneck
        int pathFlow = INF;
        for (int v = sink; v != source; v = parent[v]) {
            int u = parent[v];
            if (residual[u][v] < pathFlow)
                pathFlow = residual[u][v];
        }

        printf("Bottleneck Flow = %d\n", pathFlow);

        // Update residual graph
        for (int v = sink; v != source; v = parent[v]) {
            int u = parent[v];
            residual[u][v] -= pathFlow;
            residual[v][u] += pathFlow;
        }

        maxFlow += pathFlow;

        // Print residual graph
        printf("Residual Graph:\n");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                printf("%3d ", residual[i][j]);
            }
            printf("\n");
        }
    }

    return maxFlow;
}

int main() {
    int e, source, sink;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    memset(graph, 0, sizeof(graph));

    printf("Enter edges (u v capacity):\n");
    for (int i = 0; i < e; i++) {
        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);
        graph[u][v] = w;
    }

    printf("Enter source and sink: ");
    scanf("%d %d", &source, &sink);

    int maxFlow = edmondsKarp(source, sink);

    printf("\n====================\n");
    printf("Maximum Flow = %d\n", maxFlow);
    printf("====================\n");

    return 0;
}