#include <stdio.h>

#define MAX 100
#define INF 99999

void printMatrix(int dist[MAX][MAX], int n, int k) {
    printf("\nAfter vertex %d:\n", k);

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (dist[i][j] == INF)
                printf("%4s", "INF");
            else
                printf("%4d", dist[i][j]);
        }
        printf("\n");
    }
}

void floydWarshall(int graph[MAX][MAX], int n) {
    int dist[MAX][MAX];

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            dist[i][j] = graph[i][j];

    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (dist[i][k] != INF &&
                    dist[k][j] != INF &&
                    dist[i][k] + dist[k][j] < dist[i][j]) {

                    dist[i][j] = dist[i][k] + dist[k][j];
                }
            }
        }

        printMatrix(dist, n, k);
    }

    // Negative cycle check
    for (int i = 0; i < n; i++) {
        if (dist[i][i] < 0) {
            printf("\nNegative cycle detected!\n");
            return;
        }
    }

    printf("\nFinal shortest distance matrix printed above.\n");
}

int main() {
    int n, e;
    int graph[MAX][MAX];

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            graph[i][j] = (i == j) ? 0 : INF;

    printf("Enter edges (u v w):\n");
    for (int i = 0; i < e; i++) {
        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);
        graph[u][v] = w;
        // graph[v][u] = w; // uncomment if undirected
    }

    floydWarshall(graph, n);

    return 0;
}