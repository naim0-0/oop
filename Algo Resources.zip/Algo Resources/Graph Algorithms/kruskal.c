#include <stdio.h>
#include <stdlib.h>

#define MAX 100

// Edge structure
struct Edge {
    int u, v, w;
};

// Disjoint Set (Union-Find)
int parent[MAX];

int find(int i) {
    while (parent[i] != i)
        i = parent[i];
    return i;
}

void unionSets(int a, int b) {
    int rootA = find(a);
    int rootB = find(b);
    parent[rootA] = rootB;
}

// Sorting edges by weight (Bubble Sort for simplicity)
void sortEdges(struct Edge edges[], int e) {
    for (int i = 0; i < e - 1; i++) {
        for (int j = 0; j < e - i - 1; j++) {
            if (edges[j].w > edges[j + 1].w) {
                struct Edge temp = edges[j];
                edges[j] = edges[j + 1];
                edges[j + 1] = temp;
            }
        }
    }
}

void kruskal(struct Edge edges[], int n, int e) {
    struct Edge mst[MAX];
    int mstIndex = 0;
    int totalCost = 0;

    // Initialize parent
    for (int i = 0; i < n; i++)
        parent[i] = i;

    sortEdges(edges, e);

    for (int i = 0; i < e; i++) {
        int u = edges[i].u;
        int v = edges[i].v;

        if (find(u) != find(v)) {
            mst[mstIndex++] = edges[i];
            totalCost += edges[i].w;
            unionSets(u, v);
        }
    }

    printf("\nEdges in MST:\n");
    for (int i = 0; i < mstIndex; i++) {
        printf("%d - %d \t%d\n", mst[i].u, mst[i].v, mst[i].w);
    }

    printf("\nTotal Cost of MST: %d\n", totalCost);
}

int main() {
    int n, e;
    struct Edge edges[MAX];

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter edges (u v w):\n");
    for (int i = 0; i < e; i++) {
        scanf("%d %d %d", &edges[i].u, &edges[i].v, &edges[i].w);
    }

    kruskal(edges, n, e);

    return 0;
}